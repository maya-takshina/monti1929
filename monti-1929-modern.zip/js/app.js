const menuItems = window.menuItems || [];

const categories = ["Усе", ...new Set(menuItems.map((item) => item.category))];
const state = {
  category: "Усе",
  search: "",
  cart: [],
};

const categoryBar = document.querySelector("#categoryBar");
const menuGrid = document.querySelector("#menuGrid");
const menuCount = document.querySelector("#menuCount");
const searchInput = document.querySelector("#searchInput");
const cartList = document.querySelector("#cartList");
const cartTotal = document.querySelector("#cartTotal");
const clearCart = document.querySelector("#clearCart");

function formatPrice(price) {
  return `${price.toLocaleString("uk-UA")} грн`;
}

function getInitials(name) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0])
    .join("")
    .toUpperCase();
}

function renderCategories() {
  categoryBar.innerHTML = categories
    .map(
      (category) => `
        <button class="category-btn ${category === state.category ? "active" : ""}"
          type="button"
          data-category="${category}">
          ${category}
        </button>
      `,
    )
    .join("");
}

function getFilteredItems() {
  const term = state.search.trim().toLowerCase();

  return menuItems.filter((item) => {
    const categoryMatch = state.category === "Усе" || item.category === state.category;
    const searchMatch =
      !term ||
      item.name.toLowerCase().includes(term) ||
      item.description.toLowerCase().includes(term) ||
      item.category.toLowerCase().includes(term);

    return categoryMatch && searchMatch;
  });
}

function renderMenu() {
  const items = getFilteredItems();
  menuCount.textContent = `${items.length} з ${menuItems.length} позицій`;

  if (!items.length) {
    menuGrid.innerHTML = `<p class="empty-state">Нічого не знайдено. Спробуйте іншу категорію або пошук.</p>`;
    return;
  }

  menuGrid.innerHTML = items
    .map(
      (item) => `
        <article class="dish-card ${item.popular ? "featured" : ""}">
          <div class="dish-media">
            ${
              item.photo
                ? `<img src="${item.photo}" alt="${item.name}" loading="lazy">`
                : `<div class="dish-placeholder" aria-hidden="true">${getInitials(item.name)}</div>`
            }
            <span class="dish-tag">${item.category}</span>
          </div>
          <div class="dish-body">
            <div>
              <h3>${item.name}</h3>
              <p>${item.description}</p>
            </div>
            <div class="dish-bottom">
              <span class="price">${formatPrice(item.price)}</span>
              <button class="add-btn" type="button" data-item="${item.id}" aria-label="Додати ${item.name}">+</button>
            </div>
          </div>
        </article>
      `,
    )
    .join("");
}

function renderCart() {
  if (!state.cart.length) {
    cartList.innerHTML = `<p class="empty">Додайте улюблені позиції з меню.</p>`;
    cartTotal.textContent = formatPrice(0);
    return;
  }

  const grouped = state.cart.reduce((items, item) => {
    const existing = items.find((entry) => entry.name === item.name);
    if (existing) {
      existing.qty += 1;
    } else {
      items.push({ ...item, qty: 1 });
    }
    return items;
  }, []);

  cartList.innerHTML = grouped
    .map(
      (item) => `
        <div class="cart-item">
          <span><strong>${item.qty}×</strong> ${item.name}</span>
          <strong>${formatPrice(item.price * item.qty)}</strong>
        </div>
      `,
    )
    .join("");

  const total = state.cart.reduce((sum, item) => sum + item.price, 0);
  cartTotal.textContent = formatPrice(total);
}

categoryBar.addEventListener("click", (event) => {
  const button = event.target.closest("[data-category]");
  if (!button) return;

  state.category = button.dataset.category;
  renderCategories();
  renderMenu();
});

menuGrid.addEventListener("click", (event) => {
  const button = event.target.closest("[data-item]");
  if (!button) return;

  const item = menuItems.find((entry) => String(entry.id) === button.dataset.item);
  if (!item) return;

  state.cart.push(item);
  renderCart();
});

searchInput.addEventListener("input", (event) => {
  state.search = event.target.value;
  renderMenu();
});

clearCart.addEventListener("click", () => {
  state.cart = [];
  renderCart();
});

renderCategories();
renderMenu();
renderCart();
